package com.grupo4.hostingbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HostingBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
