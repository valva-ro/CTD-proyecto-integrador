package com.grupo4.hostingbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HostingBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(HostingBookApplication.class, args);
	}

}
